//
//  ApiConfigurationStub.swift
//  MoviesTests
//
//  Created by Anton Gorlov on 29.08.2022.
//

import Foundation
import MapKit

@testable import Movies

// Configuration stub
struct APIConfigurationStub: IMoviesAPIConfiguration {
    
    var imageURL: URL {
        
        return URL(string: "imageURL")!
    }
    
    var baseURL: URL {
        
        return URL(string: "testURL")!
    }
    
    var apiKey: String {
        
        return "123456789"
    }
    
}
