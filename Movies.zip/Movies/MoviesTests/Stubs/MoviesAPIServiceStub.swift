//
//  MoviesAPIServiceStub.swift
//  MoviesTests
//
//  Created by Anton Gorlov on 29.08.2022.
//

import Foundation
import Combine
import SwiftUI
import BackendAPI

@testable import Movies

/// Movies API service stub
class MoviesAPIServiceStub: IMoviesAPIService {
    
    func getTopRatedMovies(apiKey: String, page: Int) -> TopRatedMoviesResult {
        
        let movie1 = MovieModel(id: 1,
                                   title: "title1",
                                posterPath: "someImageString1")
        
        let movie2 = MovieModel(id: 2,
                                   title: "title2",
                                posterPath: "someImageString2")
        
        let topMovies = MoviesModel(movies: [movie1, movie2],
                                         typeOfList: .top,
                                         totalPage: 999)
        
        return Just((topMovies))
            .flatMap { response -> TopRatedMoviesResult in
                
                return Future { promise in
                    
                    guard !response.movies.isEmpty else {
                        
                        promise(.failure(.emptyMovies))
                        return
                    }
                  
                    promise(.success(response))
                }
                .eraseToAnyPublisher()
            }
            .eraseToAnyPublisher()
    }
    
    func getPopularMovies(apiKey: String, page: Int) -> PopularMoviesResult {
        
        let movie1 = MovieModel(id: 1,
                                   title: "title1", posterPath: "someImageString1")
        
        let movie2 = MovieModel(id: 2,
                                   title: "title2", posterPath: "someImageString2")
        
        let popularMovies = MoviesModel(movies: [movie1, movie2],
                                        typeOfList: .popular,
                                        totalPage: 999)
        
        return Just((popularMovies))
            .flatMap { response -> PopularMoviesResult in
                
                return Future { promise in
                    
                    guard !response.movies.isEmpty else {
                        
                        promise(.failure(.emptyMovies))
                        return
                    }
                    promise(.success(response))
                }
                .eraseToAnyPublisher()
            }
            .eraseToAnyPublisher()
    }
    
    func getMovieDetails(apiKey: String, movieID: Int) -> MovieDetailsResult {
        
        let movie = MovieDetailsModel(title: "Some title",
                                      releaseDate: "10.10.2010",
                                      genres: "Action",
                                      overview: "Some overview",
                                      posterPath: "somePosterPath",
                                      backdropPath: "somebackdropPath")
        
        return Just((movie))
            .flatMap { response -> MovieDetailsResult in
                
                return Future { promise in
                    
                    promise(.success(response))
                }
                .eraseToAnyPublisher()
            }
            .eraseToAnyPublisher()
    }
    
    
}
