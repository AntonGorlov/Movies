//
//  MoviesTests.swift
//  MoviesTests
//
//  Created by Anton Gorlov on 27.08.2022.
//

import XCTest
import Combine
import SwiftUI
@testable import Movies

class MoviesTests: XCTestCase {

    private var cancellables: Set<AnyCancellable>!
    
    override func setUp() {
        
        super.setUp()
        
        cancellables = []
    }
    
    /// Top and popular movies testing
    func testIsEmptyMovies() {
        
        //given
        let sut = makeSUT()

        //when
        var resultMovies = MoviesModel(movies: [],
                                       typeOfList: .none,
                                       totalPage: 0)
        
        sut.getPopularMovies(apiKey: "", page: 1)
            .sink(receiveCompletion: { result in
                
            }, receiveValue: { movie in
                
               resultMovies = movie
         
            })
            .store(in: &self.cancellables)
        
        //then
        XCTAssertFalse(resultMovies.movies.isEmpty, "Movies is nil")
    }
    
    /// This test to determine what type of movies comes from the backend
    /// Popular or TopRated. If TypeOfListMovies = . none - it's wrong state
    func testRightTypeOfMoviesList() {
        
        //given
        let sut = makeSUT()
        
        //when
        let testableTypeOfList: TypeOfListMovies = .none
        
        sut.getTopRatedMovies(apiKey: "", page: 1)
            .sink { result in
                
            } receiveValue: { moviesModel in
                
                //then
                XCTAssertNotEqual(moviesModel.typeOfList, testableTypeOfList, "Type of list movies cannot be set")
            }
            .store(in: &self.cancellables)
    }
    
    func testMovieDetails() throws {
        
        //given
        let sut = makeSUT()
        
        //when
        var movieModel: MovieDetailsModel?
        
        sut.getMovieDetails(apiKey: "", movieID: 0)
            .sink { _ in
                
            } receiveValue: { movie in
                
                movieModel = movie
            }
            .store(in: &self.cancellables)
        
        //then
        let unwrappedValue = try XCTUnwrap(movieModel)
        XCTAssertEqual(unwrappedValue.title, "Some title")
    }
    
    private func makeSUT() -> MoviesAPIServiceStub {
        
        return MoviesAPIServiceStub()
    }
}
