//
//  APIConfigurationTests.swift
//  MoviesTests
//
//  Created by Anton Gorlov on 29.08.2022.
//

import XCTest

class APIConfigurationTests: XCTestCase {
    
    
    func testImageAPIURL() {
        
        //given
        let sut = makeSUT()
        
        //when
        let referenceURL = URL(string: "imageURL")
        let resultURL = sut.imageURL
        
        //then
        XCTAssertEqual(resultURL, referenceURL)
    }
    func testBaseAPIURL() {
        
        //given
        let sut = makeSUT()
        
        //when
        let referenceURL = URL(string: "testURL")
        let resultURL = sut.baseURL
        
        //then
        XCTAssertEqual(resultURL, referenceURL)
    }
    
    func testAPIKey() {
        
        //given
        let sut = makeSUT()
        
        //when
        let referenceAPI = "123456789"
        let resultAPIKey = sut.apiKey
        
        //then
        XCTAssertEqual(resultAPIKey, referenceAPI)
    }
    
    private func makeSUT() -> APIConfigurationStub {
        
        let sut = APIConfigurationStub()
        
        return sut
    }
}
