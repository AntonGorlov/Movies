//
//  MoviesViewModel.swift
//  Movies
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation
import Combine
import SwiftUI

class MoviesViewModel: IMoviesViewModel, ObservableObject {
    
    @Published var isError       = false
    @Published var formErrorText = String()
    @Published var movies        = [MovieModel]()
    @Published var detailsMovie  : MovieDetailsModel
    @Published var isLoading     = false
    var typeOfList               : TypeOfListMovies = .none
    
    var currentPage = 1
    var totalPage   = 0
    
    let apiConfiguration: APIConfiguration
    let apiService = MoviesAPIService()
    
    private var cancellableBag = Set<AnyCancellable>()
    
    init(with apiConfiguration: APIConfiguration) {
        
        self.apiConfiguration = apiConfiguration
        
        // Empty initializetion
        self.detailsMovie = MovieDetailsModel(title: "",
                                              releaseDate: "",
                                              genres: "",
                                              overview: "",
                                              posterPath: "",
                                              backdropPath: "")
    }
    
    // MARK: - Errors
    
    private func processMoviesError(_ error: MoviesError) {
        
        self.isError = true
        
        switch error {
            
        case .networkCommunicationError(let error):
            
            self.formErrorText = error.localizedDescription
            
        case .unexpected:
            
            self.formErrorText = "Something went wrong. Unexpected error"
            
        case .emptyMovies:
            
            self.formErrorText = "Sorry, there are currently no available movies"
        }
    }
    
    //MARK: - Pagination
    
    func fetchMoreMovies(movie: MovieModel) {
        
        if self.currentPage == self.totalPage { return }
        let beforeLast = self.movies.dropLast()
        
        if beforeLast.last == movie {
            
            self.currentPage += 1
            
            if self.typeOfList == .popular {
                
                self.fetchPopularMovies()
                
                return
            }
            
            self.fetchTopRatedMovies()
        }
    }
    
    func clearArrayMoviesData() {
        
        self.movies.removeAll()
        self.currentPage = 1
    }
    
    //MARK: - API
    
    func fetchTopRatedMovies() {
        
        self.isLoading = true
        
        self.apiService
            .getTopRatedMovies(apiKey: self.apiConfiguration.apiKey,
                               page: self.currentPage)
            .receive(on: RunLoop.main)
            .sink { [weak self] completion in
                
                switch completion {
                    
                case .finished:
                   
                    self?.isLoading = false
                    
                case .failure(let error):
                    
                    self?.processMoviesError(error)
                }
            } receiveValue: { [weak self] topMovies in
            
                self?.typeOfList = topMovies.typeOfList
                self?.movies.append(contentsOf: topMovies.movies)
                self?.totalPage = topMovies.totalPage
            }
            .store(in: &self.cancellableBag)
    }
    
    func fetchPopularMovies() {
        
        self.isLoading = true
        
        self.apiService
            .getPopularMovies(apiKey: self.apiConfiguration.apiKey,
                              page: self.currentPage)
            .receive(on: RunLoop.main)
            .sink { [weak self] completion in
                
                switch completion {
                    
                case .finished:
                    
                    self?.isLoading = false
                    
                case .failure(let error):
                    
                    self?.processMoviesError(error)
                }
                
            } receiveValue: { [weak self] popularMovies in
      
                self?.typeOfList = popularMovies.typeOfList
                self?.movies.append(contentsOf: popularMovies.movies)
                self?.totalPage = popularMovies.totalPage
            }
            .store(in: &self.cancellableBag)
    }
    
    func fetchMovieDetails(_ movieID: Int) {
        
        self.apiService
            .getMovieDetails(apiKey: self.apiConfiguration.apiKey,
                             movieID: movieID)
            .sink { [weak self] completion in
                
                switch completion {
                    
                case .finished:
                    
                    break
                    
                case .failure(let error):
                    
                    self?.processMoviesError(error)
                }
            } receiveValue: { [weak self] detailsMovie in
                
                self?.detailsMovie = detailsMovie
            }
            .store(in: &self.cancellableBag)

    }
    
}
