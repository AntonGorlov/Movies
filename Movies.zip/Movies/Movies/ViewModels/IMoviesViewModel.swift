//
//  IMoviesViewModel.swift
//  Movies
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// ViewModel interface
protocol IMoviesViewModel {
    
    /// Get Top Rated Movies
    func fetchTopRatedMovies()
    
    /// Get Popular Movies
    func fetchPopularMovies()
    
    /// Get Movie Details
    /// - Parameter movieId: Int
    func fetchMovieDetails(_ movieID: Int)
    
    /// Clear all loading data, because we use one [MovieModel] for a few type of list (top, popular). We need to clear loaded data
    func clearArrayMoviesData()
}
