//
//  DetailsMovieView.swift
//  Movies
//
//  Created by Anton Gorlov on 29.08.2022.
//

import SwiftUI

struct DetailsMovieView: View {
    
    @Binding var detailsMovie: MovieDetailsModel
    
    var body: some View {
        
        self.movieImage(with: self.detailsMovie.backdropPath)
        
        Form {
            
            self.cellRowView(text: "Title",
                             detailText: self.detailsMovie.title)
            
            self.cellRowView(text: "Genres:",
                             detailText: self.detailsMovie.genres)
            
            self.cellRowView(text: "Release date:",
                             detailText: self.detailsMovie.releaseDate)
            
            self.overviewView
        }
        .foregroundColor(.purple)
        .background(.thickMaterial)
        
    }
    
    private func movieImage(with path: String) -> some View {
        
        AsyncImage(url: APIConfiguration()
            .imageURL
            .appendingPathComponent(path)) { image in
                
                image
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
                    .overlay(
                        
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(Color.purple, lineWidth: 3)
                    )
                    .cornerRadius(20)
                    
                
            } placeholder: {
                
                ProgressView()
                    .progressViewStyle(.circular)
                    .tint(.purple)
                    
            }
            .foregroundColor(.purple)
            .padding()
        
    }
    
    private func cellRowView(text: String, detailText: String) -> some View {
        
        HStack {
            
            Text(text)
            
            Spacer()
            
            Text(detailText)
        }
       
    }
    
    private var overviewView: some View {
        
        VStack(spacing: 16) {
            
            Text("Overview:")
            
            Text(self.detailsMovie.overview)
        }
        
    }
}

struct DetailsMovieView_Previews: PreviewProvider {
    static var previews: some View {
        
        let configuration = APIConfiguration()
        let viewModel = MoviesViewModel(with: configuration)
        
        let model = MovieDetailsModel(title: "Name film",
                                      releaseDate: "Date",
                                      genres: "ergerg",
                                      overview: "Overview",
                                      posterPath: "/2CAL2433ZeIihfX1Hb2139CX0pW.jpg",
                                      backdropPath: "/5hNcsnMkwU2LknLoru73c76el3z.jpg")
        
        DetailsMovieView(detailsMovie: .constant(model))
            .environmentObject(viewModel)
    }
}
