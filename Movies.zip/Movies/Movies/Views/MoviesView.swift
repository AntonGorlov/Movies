//
//  MoviesView.swift
//  Movies
//
//  Created by Anton Gorlov on 27.08.2022.
//

import SwiftUI

struct MoviesView: View {
    
    @ObservedObject var moviesViewModel: MoviesViewModel
    
    var body: some View {
        
        NavigationView {
            
            VStack(spacing: 16) {
                
                NavigationLink {
                    
                    MoviesListView()
                        .navigationTitle("Top movies")
                        .environmentObject(self.moviesViewModel)
                    
                } label: {
                    
                    self.cellRowView(text: "Top")
                        
                }
                .simultaneousGesture(TapGesture().onEnded {
                             
                    self.moviesViewModel.fetchTopRatedMovies()
                })
                
                NavigationLink {
                    
                    MoviesListView()
                        .navigationTitle("Popular movies")
                        .environmentObject(self.moviesViewModel)
                    
                } label: {
                    
                    self.cellRowView(text: "Popular")
                }
                .simultaneousGesture(TapGesture().onEnded{
                    
                    self.moviesViewModel.fetchPopularMovies()
                })
              
            }
            .navigationTitle("Movies:")
            .onAppear {
                
                self.moviesViewModel.clearArrayMoviesData()
            }
           
        }
        .navigationViewStyle(.stack)
    }
    
    private func cellRowView(text: String) -> some View {
        
        HStack {
            
            Text(text)
                .font(.title)
                .frame(maxWidth: .infinity, alignment: .center)
                .padding()
        }
        .frame(height: 150)
        .foregroundColor(.purple)
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.purple, lineWidth: 2)
        )
        .background(.thickMaterial)
        .cornerRadius(20)
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    
    static var previews: some View {
        
        let configuration = APIConfiguration()
        let viewModel = MoviesViewModel(with: configuration)
        
        MoviesView(moviesViewModel: viewModel)
    }
}
