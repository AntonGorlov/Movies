//
//  MoviesListView.swift
//  Movies
//
//  Created by Anton Gorlov on 28.08.2022.
//

import SwiftUI

struct MoviesListView: View {
    
    @EnvironmentObject var moviesViewModel: MoviesViewModel
    
    var body: some View {
        
        content
            .alert(moviesViewModel.formErrorText, isPresented: $moviesViewModel.isError) {
                
            }
        
    }
    
    private var content: some View {
        
        List {
            
            ForEach(self.moviesViewModel.movies) { movie in
                
                NavigationLink {
                    
                    DetailsMovieView(detailsMovie: $moviesViewModel.detailsMovie)
                    
                        .onAppear {
                            
                            self.moviesViewModel.fetchMovieDetails(movie.id)
                        }
                        .navigationTitle(movie.title)
                    
                } label: {
                    
                    cellRowView(text: movie.title,
                                imagePath: movie.posterPath)
                }
                .onAppear {
                    
                    self.moviesViewModel.fetchMoreMovies(movie: movie)
                }
            }
            
            loadingView
        }
        
    }
    
    @ViewBuilder
    private var loadingView: some View {
        
        if self.moviesViewModel.isLoading {
            
            ProgressView("Please wait...")
                .padding()
                .font(.title2)
                .tint(.purple)
                .foregroundColor(.purple)
                .frame(maxWidth: .infinity, alignment: .center)
        }
        
    }
    
    private func cellRowView(text: String, imagePath: String) -> some View {
        
        ZStack(alignment: .bottom) {
            
        self.backgroundView(imagePath: imagePath, text: text)

            Text(text)
                .font(.body)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(.thickMaterial)
        }
        .overlay(
            
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.purple, lineWidth: 3)
                .background(.clear)
        )
        .cornerRadius(20)
        .foregroundColor(.purple)
    }
    
    private func backgroundView(imagePath: String, text: String) -> some View {
        
        AsyncImage(url: APIConfiguration()
            .imageURL
            .appendingPathComponent(imagePath)) { phase in

            switch phase {

            case .empty:

                Image(systemName: "film")
                    .resizable()
                    .foregroundColor(.purple)

            case .success(let image):

                    image
                        .resizable()
                        .transition(.slide)
            
            case .failure(_):

                Image(systemName: "exclamationmark.icloud")
                    .resizable()
                   
            @unknown default:

                Image(systemName: "exclamationmark.icloud")
                    .resizable()
            }
        }
            .frame(width: UIScreen.main.bounds.width * 0.8,
                   height: UIScreen.main.bounds.height * 0.4)
    }
}
