//
//  APIConfiguration.swift
//  Movies
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation
import BackendAPI

/// Configuration for backend API. Usually use environments for different URLs (Debug, Staging or Release environment) configuration
struct APIConfiguration: IMoviesAPIConfiguration {
    
    init() {
        
        let configuration = BackendAPIConfigurator.shared
        configuration.configure(baseURL: self.baseURL)
    }
    
    var baseURL: URL {
        
        return URL(fileURLWithPath: "https://api.themoviedb.org/3/movie")
    }
    
    var imageURL: URL {
        
        return URL(fileURLWithPath: "https://image.tmdb.org/t/p/w400/")
    }
    
    var apiKey: String {
        
        return "b9700257dfd29652662caeb9300b04a2"
    }
    
}
