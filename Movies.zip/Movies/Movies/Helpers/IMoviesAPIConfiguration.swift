//
//  IMoviesAPIConfiguration.swift
//  Movies
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

protocol IMoviesAPIConfiguration {
    
    var baseURL: URL { get }
    
    var imageURL: URL { get }
    
    var apiKey: String { get }
}
