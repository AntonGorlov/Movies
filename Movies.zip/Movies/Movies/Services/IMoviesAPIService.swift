//
//  IMoviesAPIService.swift
//  Movies
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation
import Combine
import BackendAPI

protocol IMoviesAPIService {
    
    typealias TopRatedMoviesResult = AnyPublisher<MoviesModel, MoviesError>
    
    /// Top Rated Movies
    /// - Parameters:
    /// - apiKey: String
    /// - page: Int
    /// - Returns: TopRatedMoviesResult
    func getTopRatedMovies(apiKey: String,
                           page: Int) -> TopRatedMoviesResult
    
    typealias PopularMoviesResult = AnyPublisher<MoviesModel, MoviesError>
    
    /// Popular Movies
    /// - Parameter apiKey: String
    /// - Returns: PopularMoviesResult
    
    
    /// Popular Movies
    /// - Parameters:
    /// - apiKey: String
    /// - page: Int
    /// - Returns: PopularMoviesResult
    func getPopularMovies(apiKey: String,
                          page: Int) -> PopularMoviesResult
    
    typealias MovieDetailsResult = AnyPublisher<MovieDetailsModel, MoviesError>
    
    /// Movie Details
    /// - Parameters:
    ///   - apiKey: String
    ///   - movieID: String
    /// - Returns: MovieDetailsResult
    func getMovieDetails(apiKey: String, movieID: Int) -> MovieDetailsResult
}
