//
//  MoviesAPIService.swift
//  Movies
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation
import BackendAPI
import Combine

class MoviesAPIService: IMoviesAPIService {
    
    var apiAdapter: IMoviesAdapter = MoviesAdapter()
    
    func getTopRatedMovies(apiKey: String,
                           page: Int) -> TopRatedMoviesResult {
        
        let request = MoviesRequestData(apiKey: apiKey, page: page)
        
        return self.apiAdapter
            .getTopRatedMovies(requestData: request)
            .mapError { error -> MoviesError in
                
                if let networkError = NetworkCommunicationError(from: error) {
                    
                    return .networkCommunicationError(networkError)
                }
                
                return .unexpected
            }
            .flatMap({ response -> TopRatedMoviesResult in
                
                return Future { promise in
                    
                    let topMovies = Mapper<TopRatedMoviesResponseData>().map(response)
                    
                    guard !topMovies.movies.isEmpty else {
                        
                        promise(.failure(.emptyMovies))
                        return
                    }
                    promise(.success(topMovies))
                }
                .eraseToAnyPublisher()
            })
            .eraseToAnyPublisher()
    }
    
    func getPopularMovies(apiKey: String,
                          page: Int) -> PopularMoviesResult {
        
        let request = MoviesRequestData(apiKey: apiKey, page: page)
        
        return self.apiAdapter
            .getPopularMovies(requestData: request)
            .mapError { error -> MoviesError in
                
                if let networkError = NetworkCommunicationError(from: error) {
                    
                    return .networkCommunicationError(networkError)
                }
                
                return .unexpected
            }
            .flatMap ({ response -> PopularMoviesResult in
                
                return Future { promise in
                    
                    let popularMovies = Mapper<PopularMoviesResponseData>().map(response)
                    
                    guard !popularMovies.movies.isEmpty else {
                        
                        promise(.failure(.emptyMovies))
                        return
                    }
                    promise(.success(popularMovies))
                }
                .eraseToAnyPublisher()
            })
            .eraseToAnyPublisher()
    }
    
    func getMovieDetails(apiKey: String, movieID: Int) -> MovieDetailsResult {
        
        let request = MovieDetailsRequestData(apiKey: apiKey,
                                              movieId: String(movieID))
        
        return self.apiAdapter
            .getMovieDetails(requestData: request)
            .mapError { error -> MoviesError in
                
                if let networkError = NetworkCommunicationError(from: error) {
                    
                    return .networkCommunicationError(networkError)
                }
                
                return .unexpected
            }
            .flatMap { response -> MovieDetailsResult in
                
                return Future { promise in
                    
                    let movieDetails = Mapper<MovieDetailsResponseData>().map(response)
                    
                    promise(.success(movieDetails))
                }
                .eraseToAnyPublisher()
            }
            .eraseToAnyPublisher()
    }
   
}
