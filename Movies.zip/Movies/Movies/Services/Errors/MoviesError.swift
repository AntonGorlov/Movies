//
//  MoviesError.swift
//  Movies
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Movies Error
enum MoviesError: Error {
    
    case networkCommunicationError(NetworkCommunicationError)
    
    case unexpected
    
    case emptyMovies
}

