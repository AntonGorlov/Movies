//
//  NetworkCommunicationError.swift
//  Movies
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Network Communication Error
enum NetworkCommunicationError: Error {
    
    case networkUnavailable
    
    case serverUnavailable
    
    case connectionLost
}
