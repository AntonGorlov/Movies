//
//  Mapper+MovieDetailsModel.swift
//  Movies
//
//  Created by Anton Gorlov on 28.08.2022.
//

import Foundation
import BackendAPI

extension Mapper {
    
    func map(_ model: MovieDetailsResponseData) -> MovieDetailsModel {
        
        let title = model.title
        let releaseDate = model.releaseDate
        
        let genres = mappingMovieGenres(with: model.genres)
        let overview = model.overview
        let posterPath = model.posterPath
        let backdropPath = model.backdropPath
        
        return .init(title: title,
                     releaseDate: releaseDate,
                     genres: genres,
                     overview: overview,
                     posterPath: posterPath,
                     backdropPath: backdropPath)
    }
    
    private func mappingMovieGenres(with genresResponse: [GenresResponseData]) -> String {
        
        var genresString = String()
        
        for genre in genresResponse {
            
            genresString.append(genre.name)
            
            if genre != genresResponse.last {
                
                genresString.append(",")
            }
        }
        
        return genresString
    }
}
