//
//  Mapper+TopRatedMoviesModel.swift
//  Movies
//
//  Created by Anton Gorlov on 28.08.2022.
//

import Foundation
import BackendAPI

extension Mapper {
    
    func map(_ model: TopRatedMoviesResponseData) -> MoviesModel {
        
        let totalPage = model.totalPages
        let movies = model.topMovies.map { Mapper<MovieModel>().map($0) }
        
        return .init(movies: movies,
                     typeOfList: .top,
                     totalPage: totalPage)
    }
    
    func map(_ model: TopRatedMovieResponseData) -> MovieModel {
        
        let id         = model.id
        let title      = model.title
        let posterPath = model.posterPath
        
        return .init(id: id,
                     title: title,
                     posterPath: posterPath)
    }
}
