//
//  Mapper+PopularMovieModel.swift
//  Movies
//
//  Created by Anton Gorlov on 28.08.2022.
//

import Foundation
import BackendAPI

extension Mapper {
    
    func map(_ model: PopularMoviesResponseData) -> MoviesModel {
        
        let totalPage = model.totalPages
        let popularMovies = model.popularMovies.map { Mapper<PopularMovieResponseData>().map($0) }
        
        return .init(movies: popularMovies,
                     typeOfList: .popular,
                     totalPage: totalPage)
    }
    
    func map(_ model: PopularMovieResponseData) -> MovieModel {
        
        let id         = model.id
        let title      = model.title
        let posterPath = model.posterPath
        
        return .init(id: id,
                     title: title,
                     posterPath: posterPath)
    }
}
