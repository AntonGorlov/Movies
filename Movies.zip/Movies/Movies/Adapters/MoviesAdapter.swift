//
//  MoviesAdapter.swift
//  Movies
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation
import Combine
import BackendAPI

/// Adapter for Combine
class MoviesAdapter: IMoviesAdapter {
    
    var moviesAPI: IMoviesAPI = MoviesAPIController()
    
    func getTopRatedMovies(requestData: MoviesRequestData) -> TopRatedMoviesResult {
        
        return Future { promise in
            
            self.moviesAPI
                .getTopRatedMovies(with: requestData) { result in
                    
                    switch result {
                        
                    case .success(let response):
                        
                        if !response.topMovies.isEmpty {
                            
                            promise(.success(response))
                        }
                        
                        promise(.failure(.requestExecutionError(.dataIsEmpty)))
                        
                    case .failure(let error):
                        
                        promise(.failure(error))
                    }
                }
        }
        .eraseToAnyPublisher()
    }
    
    func getPopularMovies(requestData: MoviesRequestData) -> PopularMoviesResult {
        
        return Future { promise in
            
            self.moviesAPI
                .getPopularMovies(with: requestData) { result in
                
                    switch result {
                        
                    case .success(let response):
                        
                        if !response.popularMovies.isEmpty {
                            
                            promise(.success(response))
                        }
                        
                        promise(.failure(.requestExecutionError(.dataIsEmpty)))
                        
                    case .failure(let error):
                        
                        promise(.failure(error))
                    }
                }
        }
        .eraseToAnyPublisher()
    }
    
    func getMovieDetails(requestData: MovieDetailsRequestData) -> MovieDetailsResult {
        
        return Future { promise in
            
            self.moviesAPI
                .getMovieDetails(with: requestData) { result in
                    
                    switch result {
                        
                    case .success(let response):
                        
                        promise(.success(response))
                        
                    case .failure(let error):
                        
                        promise(.failure(error))
                    }
                }
        }
        .eraseToAnyPublisher()
    }
    
    
}
