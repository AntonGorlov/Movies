//
//  IMoviesAdapter.swift
//  Movies
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation
import Combine
import BackendAPI

/// Adapter interface
protocol IMoviesAdapter {
    
    typealias TopRatedMoviesResult = AnyPublisher<TopRatedMoviesResponseData,
                                                    BackendAPIError>
    
    /// TopRatedMovies
    /// - Parameter requestData: MoviesRequestData
    /// - Returns: TopRatedMoviesResult
    func getTopRatedMovies(requestData: MoviesRequestData) -> TopRatedMoviesResult
    
    typealias PopularMoviesResult = AnyPublisher<PopularMoviesResponseData,
                                                 BackendAPIError>
    
    /// PopularMovies
    /// - Parameter requestData: MoviesRequestData
    /// - Returns: PopularMoviesResult
    func getPopularMovies(requestData: MoviesRequestData) -> PopularMoviesResult
    
    typealias MovieDetailsResult = AnyPublisher<MovieDetailsResponseData,
                                                BackendAPIError>
    
    /// MovieDetails
    /// - Parameter requestData: MovieDetailsRequestData
    /// - Returns: MovieDetailsResult
    func getMovieDetails(requestData: MovieDetailsRequestData) -> MovieDetailsResult
}
