//
//  MoviesApp.swift
//  Movies
//
//  Created by Anton Gorlov on 27.08.2022.
//

import SwiftUI

@main
struct MoviesApp: App {
    
    init() {
        
        UINavigationBar.appearance().tintColor = .purple
        UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor : UIColor.purple]
    }
    
    var body: some Scene {
        WindowGroup {
            
            let apiConfiguration = APIConfiguration()
            let moviesViewModel = MoviesViewModel(with: apiConfiguration)
            MoviesView(moviesViewModel: moviesViewModel)
        }
    }
}
