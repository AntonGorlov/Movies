//
//  MovieDetailsModel.swift
//  Movies
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Model for a movie details. Use on business logic and  an UI
struct MovieDetailsModel {
    
    var title: String
    
    var releaseDate: String
  
    var genres: String
    
    var overview: String
    
    var posterPath: String
    
    var backdropPath: String
}

