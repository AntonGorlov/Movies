//
//  MoviesModel.swift
//  Movies
//
//  Created by Anton Gorlov on 08.09.2022.
//

import Foundation

/// Model for movies.
struct MoviesModel {
    
    var movies: [MovieModel]
    var typeOfList: TypeOfListMovies
    var totalPage: Int // for pagination
}
