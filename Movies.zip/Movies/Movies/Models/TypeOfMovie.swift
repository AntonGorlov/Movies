//
//  TypeOfMovie.swift
//  Movies
//
//  Created by Anton Gorlov on 08.09.2022.
//

import Foundation

/// Type of list
enum TypeOfListMovies {
    
    case top
    
    case popular
    
    case none
}
