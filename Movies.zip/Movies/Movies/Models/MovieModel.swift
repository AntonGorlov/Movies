//
//  MovieModel.swift
//  Movies
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Model for a movie. Use on business logic and  an UI
struct MovieModel: Identifiable, Equatable {
    
    var id: Int
    var title: String
    var posterPath: String
}

