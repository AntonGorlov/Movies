//
//  Configuration.swift
//  
//
//  Created by Anton Gorlov on 23.08.2022.
//

import Foundation

public struct Configuration {
    
    public var baseURL: URL
    
    //API key for example
    var commonHeaders: [String : String] = [
        
        "Content-Type" : "application/json"
    ]
}
