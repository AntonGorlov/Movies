//
//  MoviesAPIEndpointsFactory 2.swift
//  
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Endpoints Factory
class MoviesAPIEndpointsFactory: IMoviesAPIEndpointsBuilder {
    
    private(set) var configuration: Configuration
    
    init() {
        
        guard let configuration = BackendAPIConfigurator.shared.configuration else {
            
            fatalError(MISS_CONFIG_FATAL_ERROR)
        }
        
        self.configuration = configuration
    }
    
    // MARK: Endpoints
    
    var getTopRatedMoviesRequestURL: URL {
        
        return configuration
            .baseURL
            .appendingPathComponent("top_rated")
    }
    
    var getPopularMoviesRequestURL: URL {
        
        return configuration
            .baseURL
            .appendingPathComponent("popular")
    }

    var getMovieDatailRequestURL: URL {
        
        return configuration
            .baseURL
            
    }
}
