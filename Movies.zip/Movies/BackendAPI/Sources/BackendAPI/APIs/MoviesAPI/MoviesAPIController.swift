//
//  MoviesAPIController.swift
//  
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Movies API Controller
public class MoviesAPIController: AnyAPIContoller, IMoviesAPI {
    
    public var requestBuilder: IMoviesAPIRequestsBuilder = MoviesAPIRequestsFactory()
    
    public func getTopRatedMovies(with requestData: MoviesRequestData,
                                  completion: @escaping TopRatedMoviesResult) {
        
        do {
            
            let request = try self.requestBuilder.getTopRatedMovies(with: requestData,
                                                                    encoder: self.encoder)
            
            typealias Response = Result<TopRatedMoviesResponseData, RequestExecutionError>
            
            self.requestExecuter.execute(request,
                                         decoder: self.decoder) { (result: Response) in
                
                switch result {
                    
                case .success(let response):
                    
                    completion(.success(response))
                    
                case .failure(let executionError):
                    
                    completion(.failure(.requestExecutionError(executionError)))
                }
            }
        }
        catch let error as RequestBuildingError {
            
            completion(.failure(.requestBuildingError(error)))
        }
        catch {
            
            completion(.failure(.requestBuildingError(.unexpected(error))))
        }
    }
    
    public func getPopularMovies(with requestData: MoviesRequestData,
                                 completion: @escaping PopularMoviesResult) {
        
        do {
            
            let request = try self.requestBuilder.getPopularMovies(with: requestData,
                                                                   encoder: self.encoder)
            
            typealias Response = Result<PopularMoviesResponseData, RequestExecutionError>
            
            self.requestExecuter.execute(request,
                                         decoder: self.decoder) { (result: Response) in
                
                switch result {
                    
                case .success(let response):
                    
                    completion(.success(response))
                    
                case .failure(let executionError):
                    
                    completion(.failure(.requestExecutionError(executionError)))
                }
            }
        }
        catch let error as RequestBuildingError {
            
            completion(.failure(.requestBuildingError(error)))
        }
        catch {
            
            completion(.failure(.requestBuildingError(.unexpected(error))))
        }
    }
    
    public func getMovieDetails(with requestData: MovieDetailsRequestData,
                                completion: @escaping MovieDetailsResult) {
        
        do {
            
            let request = try self.requestBuilder.getMovieDetail(with: requestData,
                                                                 encoder: self.encoder)
            
            typealias Response = Result<MovieDetailsResponseData, RequestExecutionError>
            
            self.requestExecuter.execute(request,
                                         decoder: self.decoder) { (result: Response) in
                
                switch result {
                    
                case .success(let response):
                    
                    completion(.success(response))
                    
                case .failure(let executionError):
                    
                    completion(.failure(.requestExecutionError(executionError)))
                }
            }
        }
        catch let error as RequestBuildingError {
            
            completion(.failure(.requestBuildingError(error)))
        }
        catch {
            
            completion(.failure(.requestBuildingError(.unexpected(error))))
        }
    }
    
    
}
