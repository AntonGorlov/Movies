//
//  IMoviesAPI.swift
//  
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Movies API interface
public protocol IMoviesAPI {
    
    var requestBuilder: IMoviesAPIRequestsBuilder { get set }
    
   typealias TopRatedMoviesResult = (Result<TopRatedMoviesResponseData, BackendAPIError>) -> Void
    
    /// Get top rated movies
    /// - Parameters:
    ///   - requestData: MoviesRequestData
    ///   - completion: TopRatedMoviesResult
    func getTopRatedMovies(with requestData: MoviesRequestData, completion: @escaping TopRatedMoviesResult)
    
    
    typealias PopularMoviesResult = (Result<PopularMoviesResponseData, BackendAPIError>) -> Void
    
    /// Get Popular Movies
    /// - Parameters:
    ///   - requestData: MoviesRequestData
    ///   - completion: PopularMoviesResult
    func getPopularMovies(with requestData: MoviesRequestData, completion: @escaping  PopularMoviesResult)
    
    typealias MovieDetailsResult = (Result<MovieDetailsResponseData, BackendAPIError>) -> Void
    
    /// get Movie Details
    /// - Parameters:
    ///   - requestData: MovieDetailsRequestData
    ///   - completion: MovieDetailsResult
    func getMovieDetails(with requestData: MovieDetailsRequestData, completion: @escaping MovieDetailsResult)
}
