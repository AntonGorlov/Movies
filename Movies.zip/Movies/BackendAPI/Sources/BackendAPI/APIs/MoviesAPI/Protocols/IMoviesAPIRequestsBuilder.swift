//
//  IMoviesAPIRequestsBuilder.swift
//  
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Requests builder interface
public protocol IMoviesAPIRequestsBuilder {
    
    var endpointsBuilder: IMoviesAPIEndpointsBuilder { get set }
    
    func getTopRatedMovies(with requestData: MoviesRequestData, encoder: JSONEncoder) throws -> URLRequest
    
    func getPopularMovies(with requestData: MoviesRequestData, encoder: JSONEncoder) throws -> URLRequest
    
    func getMovieDetail(with requestData: MovieDetailsRequestData, encoder: JSONEncoder) throws -> URLRequest
}



