//
//  IMoviesAPIEndpointsBuilder.swift
//  
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Endpoints interface
public protocol IMoviesAPIEndpointsBuilder {
    
    /// List top rated movies
    var getTopRatedMoviesRequestURL: URL { get }
    
    /// List popular movies
    var getPopularMoviesRequestURL: URL { get }
    
    /// Get movie detail path
    var getMovieDatailRequestURL: URL { get }
}
