//
//  MovieDetailsRequestData.swift
//  
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Movie Detail Request Data
public struct MovieDetailsRequestData: Encodable {
    
    public let apiKey: String
    
    public let movieId: String
    
    public init( apiKey: String, movieId: String) {
        
        self.apiKey = apiKey
        self.movieId = movieId
    }
    
    enum CodingKeys: String, CodingKey {
        
        case apiKey = "api_key"
        case movieId = "movie_id"
    }

}
