//
//  PopularMoviesResponseData.swift
//  
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Popular Movies Response Data
public struct PopularMoviesResponseData: Decodable {
    
    public let popularMovies: [PopularMovieResponseData]
    
    public let totalPages: Int
    
    enum CodingKeys: String, CodingKey {
        
        case popularMovies = "results"
        case totalPages    = "total_pages"
    }
}
