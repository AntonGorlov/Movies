//
//  TopRatedMovieResponseData.swift
//  
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Top Rated Movie Response Data
public struct TopRatedMovieResponseData: Decodable {
    
    public let id: Int
    
    public let title: String
    
    public let posterPath: String
    
    enum CodingKeys: String, CodingKey {
        
        case id    = "id"
        case title = "title"
        case posterPath = "poster_path"
    }
}
