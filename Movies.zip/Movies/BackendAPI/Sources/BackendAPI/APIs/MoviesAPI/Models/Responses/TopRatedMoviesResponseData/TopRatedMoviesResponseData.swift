//
//  TopRatedMoviesResponseData.swift
//  
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Description Top Rated Movies Response Data
public struct TopRatedMoviesResponseData: Decodable {
    
    public let topMovies: [TopRatedMovieResponseData]
    
    public let totalPages: Int
    
    enum CodingKeys: String, CodingKey {
        
        case topMovies  = "results"
        case totalPages = "total_pages"
    }
}



