//
//  PopularMovieResponseData.swift
//  
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Popular Movie Response Data
public struct PopularMovieResponseData: Decodable {
    
    public let id: Int
    
    public let title: String
    
    public let posterPath: String
    
    enum CodingKeys: String, CodingKey {
        
        case id    = "id"
        case title = "title"
        case posterPath = "poster_path"
    }
}
