//
//  MovieDetailsResponseData.swift
//  
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Movie Detail Response Data
public struct MovieDetailsResponseData: Decodable {
    
    public let title: String
    
    public let releaseDate: String
  
    public let genres: [GenresResponseData] 
    
    public let overview: String
    
    public let posterPath: String
    
    public let backdropPath: String
    
    enum CodingKeys: String, CodingKey {
        
        case title        = "title"
        case releaseDate  = "release_date"
        case genres       = "genres"
        case overview     = "overview"
        case posterPath   = "poster_path"
        case backdropPath = "backdrop_path"
    }
}
