//
//  MoviesRequestData.swift
//  
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Top Rated Request Data
public struct MoviesRequestData: Encodable {
    
    public let apiKey: String
    
    public let page: Int
    
    public init(apiKey: String, page: Int) {
        
        self.apiKey = apiKey
        self.page   = page
    }
    
    enum CodingKeys: String, CodingKey {
        
        case apiKey = "api_key"
        case page   = "page"
    }
}
