//
//  GenresResponseData.swift
//  
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation

/// Genres Response Data
public struct GenresResponseData: Decodable, Equatable {
    
    public let id: Int
    
    public let name: String
}

