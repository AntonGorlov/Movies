//
//  MoviesAPIRequestsFactory.swift
//  
//
//  Created by Anton Gorlov on 27.08.2022.
//

import Foundation
import Alamofire

// Requests Factory
class MoviesAPIRequestsFactory: IMoviesAPIRequestsBuilder {
    
    var endpointsBuilder: IMoviesAPIEndpointsBuilder
    
    init() {
        
        self.endpointsBuilder = MoviesAPIEndpointsFactory()
    }
    
    func getTopRatedMovies(with requestData: MoviesRequestData,
                           encoder: JSONEncoder) throws -> URLRequest {
        
        do {
            
            guard let configuration = BackendAPIConfigurator.shared.configuration else {
                
                fatalError(MISS_CONFIG_FATAL_ERROR)
            }
            
            let endPoint = self.endpointsBuilder.getTopRatedMoviesRequestURL
            
            let headers = HTTPHeaders(configuration.commonHeaders)
            
            let request = AF.request(endPoint,
                                     method: .get,
                                     parameters: requestData,
                                     headers: headers)
            
            return try request.convertible.asURLRequest()
        }
        catch let error as EncodingError {
            
            throw RequestBuildingError.serializationError(error)
        }
        catch let initializationError {
            
            throw RequestBuildingError.urlRequestInitializationError(initializationError)
        }
    }
    
    func getPopularMovies(with requestData: MoviesRequestData,
                          encoder: JSONEncoder) throws -> URLRequest {
        
        do {
            
            guard let configuration = BackendAPIConfigurator.shared.configuration else {
                
                fatalError(MISS_CONFIG_FATAL_ERROR)
            }
            
            let endPoint = self.endpointsBuilder.getPopularMoviesRequestURL
            
            let headers = HTTPHeaders(configuration.commonHeaders)
            
            let request = AF.request(endPoint,
                                     method: .get,
                                     parameters: requestData,
                                     headers: headers)
                    
            return try request.convertible.asURLRequest()
            
        }
        catch let error as EncodingError {
            
            throw RequestBuildingError.serializationError(error)
        }
        catch let initializationError {
            
            throw RequestBuildingError.urlRequestInitializationError(initializationError)
        }
    }
    
    func getMovieDetail(with requestData: MovieDetailsRequestData,
                        encoder: JSONEncoder) throws -> URLRequest {
        
        do {
            
            guard let configuration = BackendAPIConfigurator.shared.configuration else {
                
                fatalError(MISS_CONFIG_FATAL_ERROR)
            }
            
            // workaround. Because https://api.themoviedb.org/3/movie/616037?api_key=b9700257dfd29652662caeb9300b04a2&language=en-US
            //Path Parameters "movie_id" integer without key and added in URL PATH!!!
            let endPoint = self.endpointsBuilder.getMovieDatailRequestURL
            let newEndPoint = endPoint.appendingPathComponent(requestData.movieId)
            
            let headers = HTTPHeaders(configuration.commonHeaders)
          
            let request = AF.request(newEndPoint,
                                     method: .get,
                                     parameters: requestData,
                                     headers: headers)
                    
            return try request.convertible.asURLRequest()
        }
        catch let error as EncodingError {
            
            throw RequestBuildingError.serializationError(error)
        }
        catch let initializationError {
            
            throw RequestBuildingError.urlRequestInitializationError(initializationError)
        }
    }
    
    
}
